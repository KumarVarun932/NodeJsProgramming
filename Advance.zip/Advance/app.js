const express = require("express");

//create a web server
const serv = express();

serv.get("/home",(req,res)=>{
    //res.send("<h1> Hello I am coming from the server</h1>"); check this line of example only or 
    //------To check if the json can be sent
    /*const obj = {
        name : "Varun Kumar",
        age : 15,
        email : "varun5nov@gmail.com"
    }
    res.send(obj);*/

    /*----Example 2 to send the json with some data*/
    res.status(200).json({status:"true", user:{
        name:"Varun Kumar",
        email: "varun5nov@gmail.com",
        age: 15
        }
    });
    //---------End of code for checking if json can be sent

})
serv.listen(8000,()=>{
    console.log("Server is listening at port 8000 !");
});


